from config import from_envvar

app_config = from_envvar()
